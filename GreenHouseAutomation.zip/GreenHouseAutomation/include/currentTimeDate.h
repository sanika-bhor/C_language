struct Time {
    int hour;
    int minute;
    int seconds;
};

struct Date
{
    int day;
    int month;
    int year;
};